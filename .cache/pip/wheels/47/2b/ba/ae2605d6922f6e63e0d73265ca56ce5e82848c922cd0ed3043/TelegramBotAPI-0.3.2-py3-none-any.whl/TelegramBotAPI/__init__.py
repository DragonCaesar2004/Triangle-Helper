"""
TelegramBotAPI
  source:    https://github.com/sourcesimian/pyTelegramBotAPI
  reference: https://core.telegram.org/bots/api

Usage:
  see unit tests
"""
