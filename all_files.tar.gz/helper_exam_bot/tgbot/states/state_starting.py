from aiogram.dispatcher.filters.state import StatesGroup, State


class Starting(StatesGroup):
    # grade = State()
    # subject = State()
    daily_task_count = State()
